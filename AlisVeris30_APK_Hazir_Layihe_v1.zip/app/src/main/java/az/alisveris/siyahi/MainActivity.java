package az.alisveris.siyahi;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.*;
import android.widget.*;
import android.text.*;
import org.json.*;

public class MainActivity extends Activity {
  final int COUNT=30;
  EditText[] names=new EditText[COUNT], amounts=new EditText[COUNT];
  Spinner[] units=new Spinner[COUNT];
  CheckBox[] checks=new CheckBox[COUNT];
  android.content.SharedPreferences prefs;
  boolean loading=true;
  int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
  @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("shopping",MODE_PRIVATE); build();}
  TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(35,48,58));return t;}
  void build(){
    LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(12),dp(14),dp(12),dp(8));root.setBackgroundColor(0xfff6f8fa);setContentView(root);
    TextView title=text("Alış-veriş siyahısı",23);title.setTypeface(null,1);root.addView(title);
    TextView sub=text("30 məhsul • Alınanları işarələ",13);root.addView(sub);
    ScrollView scroll=new ScrollView(this);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout list=new LinearLayout(this);list.setOrientation(1);scroll.addView(list);
    for(int i=0;i<COUNT;i++){
      final int idx=i;
      LinearLayout row=new LinearLayout(this);row.setOrientation(1);row.setPadding(dp(5),dp(9),dp(5),dp(9));list.addView(row,new LinearLayout.LayoutParams(-1,-2));
      LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);row.addView(top);
      TextView no=text((i+1)+".",16);top.addView(no,new LinearLayout.LayoutParams(dp(34),-2));
      names[i]=new EditText(this);names[i].setSingleLine(true);names[i].setTextSize(15);names[i].setHint("Məhsulun adı");top.addView(names[i],new LinearLayout.LayoutParams(0,dp(48),1));
      checks[i]=new CheckBox(this);checks[i].setText("Alınıb");checks[i].setTextSize(12);top.addView(checks[i]);
      LinearLayout bottom=new LinearLayout(this);bottom.setPadding(dp(34),0,0,0);bottom.setGravity(Gravity.CENTER_VERTICAL);row.addView(bottom);
      amounts[i]=new EditText(this);amounts[i].setSingleLine(true);amounts[i].setInputType(8194);amounts[i].setTextSize(15);amounts[i].setHint("Miqdar");bottom.addView(amounts[i],new LinearLayout.LayoutParams(0,dp(44),1));
      units[i]=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"ədəd","kq","litr"});units[i].setAdapter(adapter);bottom.addView(units[i],new LinearLayout.LayoutParams(dp(110),dp(44)));
      names[i].setText(prefs.getString("n"+i,""));amounts[i].setText(prefs.getString("a"+i,""));units[i].setSelection(prefs.getInt("u"+i,0));checks[i].setChecked(prefs.getBoolean("c"+i,false));strike(i);
      TextWatcher watcher=new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){save(idx);} public void afterTextChanged(Editable e){}};
      names[i].addTextChangedListener(watcher);amounts[i].addTextChangedListener(watcher);
      units[i].setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){save(idx);}});
      checks[i].setOnCheckedChangeListener((button,checked)->{strike(idx);save(idx);});
      View line=new View(this);line.setBackgroundColor(0xffe0e5e9);list.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
    }
    loading=false;
    LinearLayout buttons=new LinearLayout(this);buttons.setPadding(0,dp(8),0,0);root.addView(buttons);
    Button copy=new Button(this);copy.setText("Kopyala");buttons.addView(copy,new LinearLayout.LayoutParams(0,dp(54),1));copy.setOnClickListener(v->{((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Alış-veriş",export()));Toast.makeText(this,"Siyahı kopyalandı",Toast.LENGTH_SHORT).show();});
    Button send=new Button(this);send.setText("Göndər");buttons.addView(send,new LinearLayout.LayoutParams(0,dp(54),1));send.setOnClickListener(v->{Intent in=new Intent(Intent.ACTION_SEND);in.setType("text/plain");in.putExtra(Intent.EXTRA_TEXT,export());startActivity(Intent.createChooser(in,"Siyahını göndər"));});
    Button archive=new Button(this);archive.setText("Siyahılar");buttons.addView(archive,new LinearLayout.LayoutParams(0,dp(54),1));archive.setOnClickListener(v->showArchives());
    Button clear=new Button(this);clear.setText("Yeni");buttons.addView(clear,new LinearLayout.LayoutParams(0,dp(54),1));clear.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Yeni boş siyahı?").setMessage("Cari siyahı əvvəlcə arxivdə saxlanacaq.").setNegativeButton("Ləğv et",null).setPositiveButton("Yarat",(d,w)->{archiveCurrent();for(int i=0;i<COUNT;i++){names[i].setText("");amounts[i].setText("");units[i].setSelection(0);checks[i].setChecked(false);}for(int i=0;i<COUNT;i++)save(i);}).show());
  }
  void archiveCurrent(){
    try {JSONArray all=new JSONArray(prefs.getString("archives","[]"));JSONArray rows=new JSONArray();boolean has=false;
      for(int i=0;i<COUNT;i++){JSONObject o=new JSONObject();String name=names[i].getText().toString();if(!name.trim().isEmpty())has=true;o.put("n",name);o.put("a",amounts[i].getText().toString());o.put("u",units[i].getSelectedItemPosition());o.put("c",checks[i].isChecked());rows.put(o);}
      if(!has)return;JSONObject snapshot=new JSONObject();snapshot.put("date",new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm",java.util.Locale.getDefault()).format(new java.util.Date()));snapshot.put("rows",rows);all.put(snapshot);prefs.edit().putString("archives",all.toString()).apply();
    }catch(Exception e){Toast.makeText(this,"Saxlama xətası",Toast.LENGTH_SHORT).show();}
  }
  void showArchives(){
    try{JSONArray all=new JSONArray(prefs.getString("archives","[]"));if(all.length()==0){Toast.makeText(this,"Hələ saxlanmış siyahı yoxdur",Toast.LENGTH_SHORT).show();return;}
      String[] labels=new String[all.length()];for(int i=0;i<all.length();i++)labels[i]=(i+1)+". "+all.getJSONObject(i).optString("date","Siyahı");
      new AlertDialog.Builder(this).setTitle("Əvvəlki siyahılar").setItems(labels,(d,which)->new AlertDialog.Builder(this).setTitle("Siyahını aç?").setMessage("Cari siyahı əvvəlcə saxlanacaq.").setNegativeButton("Ləğv et",null).setPositiveButton("Aç",(dialog,w)->{try{JSONArray current=new JSONArray(prefs.getString("archives","[]"));JSONObject selected=current.getJSONObject(which);archiveCurrent();JSONArray rows=selected.getJSONArray("rows");loading=true;for(int i=0;i<COUNT;i++){JSONObject o=rows.getJSONObject(i);names[i].setText(o.optString("n"));amounts[i].setText(o.optString("a"));units[i].setSelection(o.optInt("u"));checks[i].setChecked(o.optBoolean("c"));strike(i);}loading=false;for(int i=0;i<COUNT;i++)save(i);}catch(Exception e){loading=false;Toast.makeText(this,"Açılmadı",Toast.LENGTH_SHORT).show();}}).show()).setNegativeButton("Bağla",null).show();
    }catch(Exception e){Toast.makeText(this,"Arxiv oxunmadı",Toast.LENGTH_SHORT).show();}
  }
  void strike(int i){int f=names[i].getPaintFlags();names[i].setPaintFlags(checks[i].isChecked()?f|Paint.STRIKE_THRU_TEXT_FLAG:f&~Paint.STRIKE_THRU_TEXT_FLAG);}
  void save(int i){if(loading)return;prefs.edit().putString("n"+i,names[i].getText().toString()).putString("a"+i,amounts[i].getText().toString()).putInt("u"+i,units[i].getSelectedItemPosition()).putBoolean("c"+i,checks[i].isChecked()).apply();}
  String export(){StringBuilder sb=new StringBuilder("ALIŞ-VERİŞ SİYAHISI\n");int n=0;for(int i=0;i<COUNT;i++){String name=names[i].getText().toString().trim();if(name.isEmpty())continue;n++;sb.append(i+1).append(". ").append(checks[i].isChecked()?"☑ ":"☐ ").append(name);String amount=amounts[i].getText().toString().trim();if(!amount.isEmpty())sb.append(" — ").append(amount).append(" ").append(units[i].getSelectedItem());sb.append("\n");}if(n==0)sb.append("Siyahı boşdur.");return sb.toString();}
}
