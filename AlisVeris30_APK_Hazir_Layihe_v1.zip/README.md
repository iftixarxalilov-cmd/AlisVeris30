Alış-veriş siyahısı Android layihəsi. GitHub-a layihənin içindəki faylları yükləyin, Actions > Alis Veris APK > Run workflow. APK Actions artifact hissəsində olacaq.
